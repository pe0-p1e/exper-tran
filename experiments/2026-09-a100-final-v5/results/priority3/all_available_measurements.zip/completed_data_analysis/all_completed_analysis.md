# 已完成实验数据的综合分析（A100 v5）

此报告汇总**全部已完整结束**的 layer pilot（8 pair × 5 layers × 10 directions × 50 images）与 pull/push 消融（3 pair × 3 arms × 10 directions × 50 images）。P02/P14/P23 的 full-90 target 评估已完成；本报告聚焦原始 8-pair 层实验与三组方法消融，完整主结果见优先三 pair 的总报告。

## 数据覆盖与可比性

每个 layer pilot CSV 有 80 个唯一 pair-transition cell、每 cell 50 张 clean-valid 图，5 层使用同一组 80 个 cell。三组 ablation 各有 30 个相同的 pair-transition cell，每组 1,500 张。主 TASR 的分母是 proxy 命中数；PSR/ASR 的分母是所有 clean-valid 图。两种 TASR 口径均保存在行级 CSV。**proxy 命中数为 0 时条件 TASR 未定义，不写作 0%。**下面是运行时的 full-90 状态快照（会随评估推进）：

| Pair | Attack PNG complete | Target evaluated | Expected full90 |
|---|---|---|---|
| P02 | 90 | 90 | 90 |
| P14 | 90 | 90 | 90 |
| P23 | 90 | 90 | 90 |
| P16 | 90 | 21 | 90 |
| P19 | 68 | 10 | 90 |
| P20 | 90 | 10 | 90 |
| P21 | 90 | 10 | 90 |
| P22 | 57 | 10 | 90 |

## 关键发现 1：最终层不是每个 pair 的最优层

表中是 pilot TASR（%，每 pair 每层 N=500）。

| Pair | 1% | 25% | 50% | 75% | 100% | Peak layer |
|---|---|---|---|---|---|---|
| P02 | — | 0.0 | 1.6 | 1.2 | 1.6 | 50% |
| P14 | — | 25.0 | 76.7 | 70.9 | 57.9 | 50% |
| P23 | — | 0.0 | 9.8 | 6.1 | 4.2 | 50% |
| P16 | — | — | 28.0 | 27.9 | 20.4 | 50% |
| P19 | — | — | — | 92.5 | 99.8 | 100% |
| P20 | — | 0.0 | 74.2 | 76.9 | 63.3 | 75% |
| P21 | — | 0.0 | 20.2 | 27.2 | 19.4 | 75% |
| P22 | — | — | 0.0 | 90.0 | 99.8 | 100% |

原 full-90 按 clean-valid 口径选择了 100% 层。按当前 proxy 条件分母重新计算，全部 8 pair 合并时，100% 层为 46.97%，75% 为 44.67%。当前优先评估的 P02/P14/P23 在 pilot 上按三 pair 等权汇总，50% 层为 **29.37%**，75% 为 **26.07%**，100% 为 **21.24%**。100% 是先前固定的统一设置，**并非这三个 pair 的最佳 pilot 层**。full-90 的结论应描述为“固定最终层下的迁移”，不能描述为三个 pair 各自优化过层深后的峰值表现。

![Layer TASR and PSR heatmap](layer_tasr_psr_heatmap.png)

## 关键发现 2：proxy 成功与 target 迁移之间存在明显落差

在 layer 100% pilot 上，三个主 pair 的 PSR 与 TASR 如下；同层 mean CKA 与 target 表示位移一起列出，避免把 proxy 成功等同于迁移成功。

| Pair | PSR % | TASR % | Mean CKA | Mean ΔR |
|---|---|---|---|---|
| P02 | 88.600 | 1.580 | 0.865 | 0.074 |
| P14 | 79.800 | 57.895 | 0.900 | 0.095 |
| P23 | 80.000 | 4.250 | 0.834 | 0.055 |

P02 与 P23 的 proxy 成功已高，但 target TASR 很低。P14 的 proxy 成功率与 P23 接近，却有更高迁移率。这是当前数据支持的现象；由于 P02 的 proxy 规模和 target family 都不同，不能只用“跨家族”一个因素解释全部差异。

![Pilot geometry versus transfer](pilot_geometry_vs_transfer.png)

## 关键发现 3：CKA 上升不保证最终迁移率上升

跨 28 个有正条件分母的 pair-layer 聚合点，mean CKA 与条件 TASR 的 Spearman ρ=+0.44，mean target 表示位移 ΔR 与条件 TASR 的 ρ=+0.78。这些是描述性关联，层深、pair family 和样本重复都混在一起，不作独立样本显著性结论。具体看 P14：75%→100% 时 CKA 从 0.743 升至 0.900，条件 TASR 从 70.9% 变为 57.9%；P23 的 CKA 从 0.729 升至 0.834，条件 TASR 从 6.1% 变为 4.2%。因此 CKA 可反映整体表示对齐，却不能单独预测哪层的攻击梯度最能推动 victim 的目标分类。相应层的 ΔR 也应一起看。

## 关键发现 4：pull+push 的收益不完全均匀

消融使用 P02/P14/P23 的相同 10 个 directions、相同 50 张图/方向。下表 TASR 为百分比。

| Pair | Pull only | Pull + push | Push only |
|---|---|---|---|
| P02 | 1.8 | 1.6 | — |
| P14 | 58.9 | 76.9 | — |
| P23 | 10.6 | 9.8 | — |

合并三 pair 且按 proxy 命中数加权时，pull+push 为 29.44%，pull-only 为 24.51%，push-only 为 未定义（proxy 命中 0 张）。push-only 的主条件指标不能与另两组数值比较；其 clean-valid 结果仍保留在原始 CSV。各 pair 差异见表，因此方法优势要按 pair 给出，不应写成“每个模型组合都提高”。

![Loss ablation by pair](ablation_by_pair.png)

## 关键发现 5：pilot 的 variance 尚不足以解释方向不对称

在 layer100 的 8 pair × 5 个无序类别对（n=40）中，对 `TASR(A→B)-TASR(B→A)` 与 source−target variance 差做 Spearman，ρ=-0.12；与双向 gap-closure 差为 ρ=+0.23。这提示类别离散度**单独**不足以解释方向差，而实际攻击造成的 margin gap 变化可能更贴近结果。该 pilot 只有 5 个无序类对/模型 pair，Gemma 两组接近 TASR ceiling，且各点共享类与图片；相关性仍是探索性。full-90 分析将给每个主 pair 增加到 45 个无序类别对，并保留 per-image 数据来检验。

![Pilot asymmetry factors](pilot_asymmetry_factors.png)

各 target encoder 的类别 cosine dispersion 如下。数值是在各自原始表示空间中、对 L2 归一化的 reference embeddings 计算；这里显示结构差异，但不同模型的 PCA/t-SNE 坐标不可直接叠加比较。

![Class variance by target](class_variance_by_target.png)

## 解释边界

这些 pilot 图的 PCA/t-SNE 已有原始输出，但统计结论使用原空间 cosine、CKA/RSA、margin 和 variance；t-SNE 的二维全局距离不作定量证据。layer pilot 的 10 个 directions 承担层选择，不能同时当作独立验证。完整 80 个 heldout directions 将在三 pair full-90 评估结束后列入最终主报告。所有 CSV 与图背后的行级数据保存在本目录和原 `analysis/layers/` 中。
