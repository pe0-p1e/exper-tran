# A100 V5 全部可用测量快照

生成时间：2026-09-29T09:37:22.087704+00:00。共 720 个计划 cell，665 个有效攻击状态，33250 个逐图记录。

`attack_complete` 已生成冻结 PNG，可测攻击与表示空间指标；`complete` 还具备目标预测标签。`running` 可能是停止后的残留状态，不纳入结果。空值表示尚未测量，不等于 0。主 TASR=proxy 命中且 target 命中/ proxy 命中；proxy 未命中的样本不计主分母。未完成 pair 的 target rate 只描述已评估子集，评估顺序并非随机，不能作为 full-90 TASR 估计。

| Pair | 攻击完成/90 | 目标评估/90 | 攻击图像数 | 目标评估图像数 | proxy 命中分母 | 已评估子集条件 TASR |
|---|---:|---:|---:|---:|---:|---:|
| P02 | 90 | 90 | 4500 | 4500 | 4060 | 1.2% |
| P14 | 90 | 90 | 4500 | 4500 | 3561 | 56.6% |
| P16 | 90 | 21 | 4500 | 1050 | 1048 | 22.0% |
| P19 | 68 | 10 | 3400 | 500 | 498 | 99.8% |
| P20 | 90 | 10 | 4500 | 500 | 444 | 63.3% |
| P21 | 90 | 10 | 4500 | 500 | 499 | 19.4% |
| P22 | 57 | 10 | 2850 | 500 | 498 | 99.8% |
| P23 | 90 | 90 | 4500 | 4500 | 3564 | 2.8% |

## 文件说明

`full90_all_cells.csv` 收录所有已有攻击标量，包括 proxy success、semantic gap、pull/push 相似度、L∞、耗时、显存，以及已有的目标 TASR。`full90_all_images.csv` 收录逐图 proxy/target 命中、预测标签和 PNG 路径。`raw_states/` 保留原始 JSON 和完整输出文本。`existing_geometry/` 包含已完成 layer pilot 的 CKA、RSA、representation shift、variance、margin、gap closure、相关矩阵等原空间测量；消融结果在 `ablation_summaries/`。

## 指标口径

主 TASR = proxy 与 target 同时命中目标类的图像数 / proxy 命中目标类的图像数。PSR = proxy 命中数 / clean-valid 图像数。`unconditional_TASR` 保留全 clean-valid 分母口径。分母为 0 时主 TASR 留空。聚合应先合计分子、分母，再相除。

表示空间指标使用原始高维 embedding：CKA 是 proxy/target 在同组 reference 图上的线性 CKA；RSA 是图像相似度矩阵上三角的 Spearman 相关。Δpull = adversarial 对目标 prototype 的 cosine − clean cosine；Δpush = clean 对源 prototype 的 cosine − adversarial cosine；ΔR = Δpull + Δpush。gap closure 是 target−source cosine margin 的变化。类方差是参考云的平均 1−cosine，同时提供 covariance trace 和 effective rank。t-SNE 坐标距离仅作定性展示。

`png_perturbations.csv` 测量保存后实际 PNG 的逐图 L∞、平均绝对变化、RMS 变化与修改像素比例；这些值从 RGB 字节重读计算，可用于核对 epsilon 预算与图像扰动强度。

`attack_grad_component_cosine` 等与双梯度分量有关的字段，在 `lambda_cls=0` 且未启用 CKA 分量的主实验可能是记录用的 0 占位，不应解释成两个有效梯度的正交程度。原始 JSON 中的 NaN 在行级 CSV 中转为空值。

P02/P14/P23 的 full-90 joint PCA/t-SNE 与表示空间测量仍在运行；五组暂缓组合保留已有 layer pilot geometry、攻击标量、逐图 PNG 指标和已评估 target 子集测量，不再启动 full-90 geometry。
