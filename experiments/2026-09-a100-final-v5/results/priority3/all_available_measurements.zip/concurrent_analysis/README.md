# 目标评估进行中的同步 CPU 分析

当前三组共同已评估方向数：**90/90**。下表只比较这批相同方向；它不是最终 full-90 结果。每个 TASR 的分母仅含 proxy 命中的图像。

| Pair | 共同方向 | proxy 命中分母 | target 条件命中 | 条件 TASR | PSR |
|---|---:|---:|---:|---:|---:|
| P02 | 90 | 4060 | 50 | 1.23% | 90.22% |
| P14 | 90 | 3561 | 2014 | 56.56% | 79.13% |
| P23 | 90 | 3564 | 101 | 2.83% | 79.20% |

P14 与 P23 的冻结 adversarial PNG 共比较 **4500** 张，字节完全一致 **3826** 张。只对共同已评估、PNG 完全一致且两边 proxy 都命中的 3017 张做严格逐图配对：两者都命中 87，仅 P14 命中 1638，仅 P23 命中 2，两者都未命中 1290。

两组虽共享 Qwen2B proxy 和配置，但部分 adversarial PNG 字节不同，不能把全部样本当成完全相同的攻击输入。严格配对子集控制了 clean 图、攻击预算与实际 adversarial 像素；目标模型仍不同，结果不能单独归因于家族差异。

`proxy_diagnostics_all_frozen.csv` 覆盖所有已冻结攻击 cell 的 PSR、semantic gap、耗时、显存与 L∞；`partial_target_correlations.csv` 覆盖已有 target 评估的 pair-cell 计算探索性 Spearman。其评估顺序并非随机，完成 90 向后须重算。

五组暂缓组合的现有 target 评估子集和条件率见 `partial_target_rates_all_pairs.csv`；对应双向都已测且条件分母为正的方向差见 `partial_target_asymmetry.csv`。评估不是随机抽样，所以这些率仅描述已完成部分。

目前全部 pair 共得到 160 个双向均已评估且两边条件分母都大于 0 的无序类别对；这些不对称率同样只用于描述已测子集。
