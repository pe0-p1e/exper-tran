# Frozen final150 paired images

150 shared clean PNGs and450 adversarial PNGs: uniform, selected and FDA, each150. Pair using manifest.json. These are original evaluated PNG bytes, not resized or reconstructed.

Qwen27B/GPT uses its family-excluded proxy pool; InternVL14B and Gemma31B use their own legal pools. All methods use50steps, epsilon16/255, pure1:1 Pull/Push, DI and equal L1-normalized gradients. Exact layers/configurations and PNG hashes are in manifest.json. No final150 feedback was used for tuning. FDA denotes an adaptation, not auxiliary-classifier FDA reproduction.
